package selfish;

import selfish.deck.Oxygen;
import selfish.deck.Card;

import java.util.Collection;
import java.util.List;

public class Astronaut {
    private String name;
    private GameEngine game;

    private List<Oxygen> oxygens;

    private Collection<Card> track;

    public Astronaut(String name, GameEngine game) {
        this.name = name;
        this.game = game;
    }

    public boolean isAlive() {
        // todo implement
        return false;
    }

    public int breathe() {
        // todo implement
        return 0;
    }

    @Override
    public String toString() {
        return "Astronaut [name=" + name + "]";
    }
}
