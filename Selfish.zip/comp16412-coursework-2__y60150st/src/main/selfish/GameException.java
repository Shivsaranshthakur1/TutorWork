package selfish;

public class GameException extends Exception {
    public GameException(String msg) {
        super(msg);
    }

    public GameException(String msg, Throwable e) {
        super(msg, e);
    }
}

