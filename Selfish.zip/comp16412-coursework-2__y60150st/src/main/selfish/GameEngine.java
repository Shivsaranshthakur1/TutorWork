package selfish;

import selfish.deck.Deck;
import selfish.deck.GameDeck;
import selfish.deck.SpaceDeck;

import java.io.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;


public class GameEngine implements Serializable {
    // This class will be implemented later.
    private Random random;
    private GameDeck gameDeck;
    private GameDeck gameDiscard;
    private SpaceDeck spaceDeck;
    private SpaceDeck spaceDiscard;

    private Astronaut currentPlayer;

    private List<Astronaut> activePlayers;

    private boolean hasStarted = false;

    private List<Astronaut> corpses;


    private static final long serialVersionUID = 1L;

    public GameEngine() {
        this.random = new Random();
        this.gameDeck = new GameDeck();
        this.gameDiscard = new GameDeck();
        this.spaceDeck = new SpaceDeck();
        this.spaceDiscard = new SpaceDeck();
        this.activePlayers = new ArrayList<>();
        this.currentPlayer = null;

    }

    public GameDeck getGameDeck() {
        return gameDeck;
    }

    public GameDeck getGameDiscard() {
        return gameDiscard;
    }

    public SpaceDeck getSpaceDeck() {
        return spaceDeck;
    }

    public SpaceDeck getSpaceDiscard() {
        return spaceDiscard;
    }

    public static GameEngine loadState(String filePath) throws GameException {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(filePath))) {
            return (GameEngine) ois.readObject();
        } catch (IOException | ClassNotFoundException e) {
            throw new GameException("Error loading game state: " + e.getMessage());
        }
    }

    public void saveState(String filePath) throws GameException {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(filePath))) {
            oos.writeObject(this);
        } catch (IOException e) {
            throw new GameException("Error saving game state: " + e.getMessage());
        }
    }

    public void addPlayer(String name) throws GameException {
        if (activePlayers.size() < 6) {
            Astronaut astronaut = new Astronaut(name, this);
            activePlayers.add(astronaut);
        } else {
            throw new GameException("Maximum number of players reached");
        }
    }

    public boolean gameOver() {
        // todo implement
        return false;
    }

    public int endTurn() {
        if (!hasStarted) {
            return -1;
        }

        int currentPlayerIndex = -1;
        for (int i = 0; i < activePlayers.size(); i++) {
            if (activePlayers.get(i).equals(currentPlayer)) {
                currentPlayerIndex = i;
                break;
            }
        }

        if (currentPlayer.isAlive()) {
            currentPlayer.breathe();
        } else {
            corpses.add(currentPlayer);
            activePlayers.remove(currentPlayer);
        }

        if (gameOver()) {
            return -2;
        }

        int nextPlayerIndex = (currentPlayerIndex + 1) % activePlayers.size();
        currentPlayer = activePlayers.get(nextPlayerIndex);
        return nextPlayerIndex;
    }

    public void startGame() throws GameException {
        if (activePlayers.size() < 2) {
            throw new GameException("Not enough players to start the game");
        }

        hasStarted = true;
        currentPlayer = activePlayers.get(0);
        // basic implementation
    }

    public void startTurn() throws GameException {
        if (getFullPlayerCount() < 2) {
            throw new GameException("At least 2 players are required to start the game.");
        }

        // Shuffle the game and space decks
        gameDeck.shuffle();
        spaceDeck.shuffle();

        // Merge discard piles with their respective decks
        mergeDecks(gameDeck, gameDiscard);
        mergeDecks(spaceDeck, spaceDiscard);

        // Set hasStarted to true
        hasStarted = true;
    }




    public Astronaut getCurrentPlayer() {
        return currentPlayer;
    }

    public void mergeDecks(Deck deck1, Deck deck2) {
        while (deck2.size() > 0) {
            deck1.add(deck2.draw());
        }
    }






















    public int getFullPlayerCount() {
        // TODO: Implement the logic to return the number of players in the game.
        return 0;
    }




}

