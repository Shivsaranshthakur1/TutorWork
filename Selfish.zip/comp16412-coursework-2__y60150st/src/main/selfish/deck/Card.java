package selfish.deck;
/**
 * Represents a card in the game.
 */

public class Card {
    private String name;
    private String description;

    /**
     * Constructs a card with the given name and description.
     *
     * @param name        the name of the card
     * @param description the description of the card
     */

    public Card(String name, String description) {
        this.name = name;
        this.description = description;
    }

    public String getName() {
        return name;
    }

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return "Card [name=" + name + ", description=" + description + "]";
    }
}
