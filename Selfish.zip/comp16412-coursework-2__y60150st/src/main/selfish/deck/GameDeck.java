package selfish.deck;


import selfish.GameException;

public class GameDeck extends Deck {
    public static final String HACK_SUIT = "Hack suit";
    public static final String HOLE_IN_SUIT = "Hole in suit";
    public static final String LASER_BLAST = "Laser blast";

    public static final String OXYGEN = "Oxygen";

    public static final String OXYGEN_1 = "Oxygen(1)";

    public static final String OXYGEN_2 = "Oxygen(2)";

    public static final String OXYGEN_SIPHON = "Oxygen siphon";

    public static final String ROCKET_BOOSTER = "Rocket booster";

    public static final String SHIELD = "Shield";

    public static final String TETHER = "Tether";

    public static final String TRACTOR_BEAM = "Tractor beam";

    public GameDeck() {
        super();
    }

    public GameDeck(String path) throws GameException {
        super();
        loadCards(path);
    }

    public Oxygen[] splitOxygen(Oxygen doubleOxygen) throws GameException {
        if (doubleOxygen.getValue() != 2) {
            throw new GameException("Can only split an Oxygen card with a value of 2.");
        }

        Oxygen[] singleOxygens = new Oxygen[2];
        for (int i = 0; i < 2; i++) {
            Oxygen singleOxygen = drawOxygen(1);

            if (singleOxygen == null) {
                singleOxygen = gameDiscard.drawOxygen(1);

                if (singleOxygen == null) {
                    throw new GameException("No single-value Oxygen cards available in the deck or discard pile.");
                }
            }

            singleOxygens[i] = singleOxygen;
        }

        return singleOxygens;
    }

    public Oxygen drawOxygen(int value) {
        for (int i = 0; i < cards.size(); i++) {
            Card card = cards.get(i);
            if (card instanceof Oxygen && ((Oxygen) card).getValue() == value) {
                cards.remove(i);
                return (Oxygen) card;
            }
        }
        return null; // Return null if no matching Oxygen card is found
    }






    // This class will be implemented later.
}

