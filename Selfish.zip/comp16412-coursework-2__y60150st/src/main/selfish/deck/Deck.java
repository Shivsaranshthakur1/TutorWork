package selfish.deck;
import selfish.GameException;

import java.util.Collection;
import java.util.List;
import java.util.ArrayList;
import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;



public class Deck {
    private Collection<Card> cards;
    private final long serialVersionUID = 1L;

    // Empty constructor
    public Deck() {
        // TODO: Initialize cards collection and serialVersionUID
    }

    public int add(Card card) {
        // todo implement
        return 0;
    }

    public Card draw() {
        // todo implement
        return null;
    }

    public int size() {
        // todo implement
        return 0;
    }

    public void shuffle() {
        // todo implement
    }



    // Empty loadCards method with UML signature
    protected List<Card> loadCards(String path) throws GameException {
        List<Card> cards = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            // Read and discard the header line
            br.readLine();

            String line;

            while ((line = br.readLine()) != null) {
                String[] cardInfo = line.split(";");
                String name = cardInfo[0];
                String description = cardInfo[1];
                int quantity = Integer.parseInt(cardInfo[2]);

                for (int i = 0; i < quantity; i++) {
                    cards.add(new Card(name, description));
                }
            }
        } catch (IOException e) {
            throw new GameException("Error loading cards from file: " + path, e);
        }

        return cards;
    }






    // Other methods...
}
