package selfish.deck;

public class Oxygen extends Card {
    private int value;

    public Oxygen(int value) {
        super("Oxygen(" + value + ")", "An oxygen card with a value of " + value);
        this.value = value;
    }

    public int getValue() {
        return value;
    }

    @Override
    public String toString() {
        return "Oxygen [value=" + value + "]";
    }
}


