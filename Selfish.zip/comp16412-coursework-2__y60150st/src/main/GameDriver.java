import selfish.GameEngine;
import selfish.GameException;
import selfish.deck.GameDeck;
import selfish.deck.SpaceDeck;

import java.util.Scanner;

public class GameDriver {

    /**
     * A helper function to centre text in a longer String.
     * @param width The length of the return String.
     * @param s The text to centre.
     * @return A longer string with the specified text centred.
     */
    public static String centreString (int width, String s) {
        return String.format("%-" + width  + "s", String.format("%" + (s.length() + (width - s.length()) / 2) + "s", s));
    }

    public GameDriver() {
    }

    public static void main(String[] args) throws GameException {
        GameEngine gameEngine = new GameEngine();

        GameDeck gameDeck = new GameDeck("path/to/actionCards.txt");
        SpaceDeck spaceDeck = new SpaceDeck("path/to/spaceCards.txt");

        Scanner scanner = new Scanner(System.in);
        String input;

        System.out.println("Welcome to the Selfish game!");
        while (true) {
            System.out.println("Enter a player's name or type 'start' to begin the game:");
            input = scanner.nextLine().trim();

            if (input.equalsIgnoreCase("start")) {
                if (gameEngine.getFullPlayerCount() >= 2) {
                    break;
                } else {
                    System.out.println("At least 2 players are required to start the game.");
                    continue;
                }
            }

            gameEngine.addPlayer(input);
            System.out.println("Player " + input + " has been added.");
        }

        gameEngine.startGame();

        // The game loop
        while (!gameEngine.gameOver()) {
            gameEngine.startTurn();
            System.out.println("It's " + gameEngine.getCurrentPlayer().toString() + "'s turn.");

            // Add game logic here, like allowing the player to perform actions.

            gameEngine.endTurn();
        }

        // Save and load game state
        try {
            // Save the game state
            System.out.print("Enter the file name to save the game state: ");
            String saveFileName = scanner.nextLine();
            gameEngine.saveState(saveFileName);

            // Load the game state
            System.out.print("Enter the file name to load the game state: ");
            String loadFileName = scanner.nextLine();
            GameEngine loadedGameEngine = GameEngine.loadState(loadFileName);
        } catch (GameException e) {
            System.err.println(e.getMessage());
        }


    }

}